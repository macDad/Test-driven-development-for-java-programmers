module isbnValidator {
	requires org.junit.jupiter.api;
}