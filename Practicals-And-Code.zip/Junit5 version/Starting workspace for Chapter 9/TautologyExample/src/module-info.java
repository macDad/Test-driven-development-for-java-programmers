module TautologyExample {
	exports com.virtualpairprogrammers.tautology;

	requires org.junit.jupiter.api;
}