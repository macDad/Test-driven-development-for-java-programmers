module isbnValidator {
	requires org.junit.jupiter.api;
	requires org.mockito;
	
}